create function pga_is_leap_year(smallint) returns boolean
    immutable
    language plpgsql
as
$$
BEGIN
    IF $1 % 4 != 0 THEN
        RETURN FALSE;
    END IF;

    IF $1 % 100 != 0 THEN
        RETURN TRUE;
    END IF;

    RETURN $1 % 400 = 0;
END;
$$;

alter function pga_is_leap_year(smallint) owner to postgres;

